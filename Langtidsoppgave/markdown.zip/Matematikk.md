>[!IMPORTANT]
>Denne siden beskriver matematikken bak flere av tallene brukt i analysen. For å se analyse av dataene, se [Dataanalyse](Dataanalyse). For å se koden som bruker dette, se [Koden bak analysen](Koden%20bak%20analysen)

# Informasjon
Denne siden handler om metodene som brukes for å finne gjennomsnitt, median, typetall og variasjonsbredde.

## Gjennomsnitt
I koden er det denne linjen som står for å finne gjennomsnittet. For å finne gjennomsnitt må du legge sammen alle verdiene og dele det på mengden verdier.
```
print("Mean passthroughs per minute:", passes/(totalminutes))
```

La oss ta 3. kjøring fra datasettet brukt i analysen som eksempel.

| Minutt | Passeringer | Minutt | Passeringer |
| ------ | ----------- | ------ | ----------- |
| 0      | 0           | 13     | 0           |
| 1      | 0           | 14     | 0           |
| 2      | 1           | 15     | 1           |
| 3      | 0           | 16     | 2           |
| 4      | 0           | 17     | 0           |
| 5      | 0           | 18     | 0           |
| 6      | 0           | 19     | 2           |
| 7      | 0           | 20     | 0           |
| 8      | 0           | 21     | 1           |
| 9      | 0           | 22     | 0           |
| 10     | 1           | 23     | 3           |
| 11     | 0           | 24     | 4           |
| 12     | 0           |        |             |
For å finne gjennomsnittet ville du ha lagt sammen alle passeringene
`0+0+1+0+0+0+0+0+0+0+1+0+0+0+0+1+2+0+0+2+0+1+0+3+4 = 15`
Deretter deler vi det på mengden verdier som i dette tilfellet er mengden minutter
`15/25 = 0.6`

Gjennomsnitt kan være et nyttig tall slik at du slipper å se gjennom alle tallene, men det betyr ikke at gjennomsnitt er helt feilfritt. For eksempel hvis du har tallene `4, 1, 7382` vil gjennomsnittet være `2 462,33333` selv om mesteparten av tallene er lavere enn 5.

## Median
Median kan løse dette problemet ved å sette tallene i stigende rekkefølge. La oss bruke samme eksempel med litt ekstra tall for å vise hvordan median fungerer.
`4, 1, 7382, 11, 15, 21`

For å regne ut median er det første steget å sette tallene opp i stigende rekkefølge.
`1, 4, 11, 15, 21, 7382`

Deretter er median rett og slett tallet som er i midten.
I dette tilfellet er det både 11 og 15. når du har 2 tall i midten brukes gjennomsnittet av de to.
`11+15/2 = 13`

## Typetall
Typetall er det siste sentralmålet som er brukt i analysen. Typetallet er det tallet som dukker opp oftest. Om du har sett analysen la du kanskje merke til at typetallet var veldig ofte 0. Det var altså fordi de fleste minuttene hadde 0 passeringer. Det kan vi også se tydelig på 3. Kjøring.
Mengden passeringer er som oftest 0, dermed blir typetallet 0.

| Minutt | Passeringer | Minutt | Passeringer |
| ------ | ----------- | ------ | ----------- |
| 0      | 0           | 13     | 0           |
| 1      | 0           | 14     | 0           |
| 2      | 1           | 15     | 1           |
| 3      | 0           | 16     | 2           |
| 4      | 0           | 17     | 0           |
| 5      | 0           | 18     | 0           |
| 6      | 0           | 19     | 2           |
| 7      | 0           | 20     | 0           |
| 8      | 0           | 21     | 1           |
| 9      | 0           | 22     | 0           |
| 10     | 1           | 23     | 3           |
| 11     | 0           | 24     | 4           |
| 12     | 0           |        |             |
## Variasjonsbredde
Variasjonsbredde var ikke så mye brukt i analysen, det var mest fordi variasjonsbredden var alltid det samme som det mest aktive minuttet. Variasjonsbredde er nemlig hvor stor forskjell det er mellom det største og det minste tallet i datasettet. La oss bruke disse tallene som eksempel.
`55, 40, 35, 11, 53`

For å finne variasjonsbredden må en finne forskjellen på det største og minste tallet.
`55-11 = 44`

Altså vil variasjonsbredden for dette eksempelet være 44 siden den største variasjonen av tallene er 44. I analysen er variasjonsredden alltid det samme som det mest aktive minuttet. Det er fordi det vil nesten alltid være i hvertfall ett minutt som hadde 0 passeringer. Derfor blir variasjonsbredden `mest aktive minutt - 0`som bare er det mest aktive minuttet.