>Dette prosjektet er opprettet med hensikten å måle hvor mange ganger noen går gjennom døren til klasserommet til IMB1 og hvordan disse tallene kan endre seg i løpet av skoledagen.

>[!NOTE]
>Denne nettsiden er laget i markdown-språket med et program som heter Obsidian og deretter eksportert til HTML. Du kan finne markdown filene og mer informasjon om markdown [her](Bak%20nettsiden).
## Bakgrunn
Jeg har nylig funnet en interesse av hvordan man måler noe med laser. For eksempel er det mulig å måle hastighet. Dette kan måles med en laser og en sensor som leser om laseren treffer den. Derfra kan den loggføre hvor lang tid noe bruker på å passere ved å huske tidene når laseren stoppet og når den kom tilbake.

Det er mange flere eksempler på hva laser kan brukes til. Jeg ble inspirert av et hoverboard jeg demonterte for en stund siden. I stedet for å bruke en knapp får å vite når man sto på, brukte den en laser. Når en gikk på hoverboardet ville en bit med gummi bli dyttet mellom en laser og en sensor. Dermed kunne hoverboardet vite at det var noen på. Heretter begynte jeg og tenke hvorfor. Hvorfor brukte det en laser i stedet for bare en knapp? Jeg kom fram til at en knapp kan bli skadet med tanke på at hoverboardet er mye i bevegelse og derfor er det fornuftig å bruke en laser i stedet som ikke har noen bevegelige deler.

Med andre ord hadde jeg fra før av lyst til å måle noe med laser. Det tok ikke lang tid å komme frem til at jeg kunne måle hvor ofte noen gikk gjennom døren. Dessuten kunne det være interessant å se hvilke endringer i hvor ofte noen gikk gjennom døren som kunne skje i løpet av dagen med tanke på timer, fag og lunsj.

## Planlegging
Jeg tenkte først at jeg kunne bruke en micro:bit til å lese av en laser. Micro:bit lar deg nemlig bruke mesteparten av pins til å koble til andre enheter. Ved å bruke disse vil det være mulig å koble til en lasersensor for å lese av når laseren blir blokkert. Om du har lest på noen av de andre sidene, vil du kjapt finne ut at jeg ikke brukte en lasersensor. Jeg brukte faktisk ikke en micro:bit i det hele tatt.

Jeg støtte på et stort problem under planleggingen. Jeg hadde nemlig ingen lasersensor. Det kan være vanskelig å måle noe med en lasersensor når du ikke har en lasersensor. Heldigvis var det ikke grunn til å kaste ut prosjektet helt ennå. Skolen hadde noen dataloggere som kunne kobles til ulike sensorer. Blant dem en ~~lasersensor~~ lyssensor. Etter en kjapp tur på naturfagsrommet fikk jeg datalogger, lyssensor og en laserpenn. Planen var herfra å henge disse opp på veggen på hver side av døra og hver gang laseren ble blokkert kom lysnivået til å synke. Heretter var det bare å se på en graf når noen gikk gjennom døra.

## Iverksettelse
Etter at planen var klar var det bare å henge opp laseren og sensoren. Alt fungerte som det skulle i ca. 2 minutter. Siden laseren bare treffer på et veldig lite punkt, var det veldig vanskelig å sikte den inn. Det hjalp ikke akkurat når veggen ristet littegranne hver gang dåra ble åpnet. Her gjalt det å være løsningsorientert. Først og fremst åpnet jeg døra slik at ingen åpnet den eller slamret den når de gikk gjennom, men det var fremdeles vanskelig å treffe ordentlig med laseren. Her kommer post-it lappen inn i bildet. Ved å la laseren treffe en post-it lapp rett fremfor lyssensoren, ville laseren ha et større område å treffe og samtidig beholde høye lysnivåer på lyssensoren.

Jeg lot loggeren måle i ca. 20 minutter, men jeg endte opp med en graf som viste tyngdekraften ganske godt. Laserpennen (som vi festet med teip) datt sakte, men sikkert nedover og lysnivået ble lavere og lavere.

Det var tydelig at teip ikke var nok her, men det var ikke akkurat noen gode alternativer i dette tilfellet. Jeg gikk på leting etter en lommelykt som kunne brukes i stedet og fikk låne en fra Tobias. Lommelykten hadde et mye større område hvor den lyste som betydde at den ikke trengte å være like nøyaktig. Jeg festet lommelykten til veggen og sjekket lyssensoren. Alt gikk som jeg hadde håpet og etter noen minutter med å overvåke grafen begynte jeg planlegging av [programmeringsdelen](Koden%20bak%20analysen).
## Løsningen
Selv om jeg hadde overvåket grafen i noen minutter før jeg lot den stå og gå skjedde det utenkelige. Lyssensoren begynte å måle tall som varierte så mye at det ikke var noe nytte i dataen. Jeg tenkte at den kunne være ødelagt og byttet den ut, men fikk samme resultat.
Til slutt prøvde jeg å bare bruke lyssensoren uten laser og uten lommelykt og bare bruke lyset i rommet. Selv om det ble mye lavere lysnivå var det mulig å se når noen gikk gjennom døra.
Nå gjensto det bare å måle i en stund, analysere dataen og lage denne nettsiden.

## Se også:
* [Dataanalysen](Dataanalyse)
	* [Koden bak analysen](Koden%20bak%20analysen)
	* [Matematikken](Matematikk)
* [Bak nettside](Bak%20nettsiden)