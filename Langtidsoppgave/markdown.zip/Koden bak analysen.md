---

---
>[!IMPORTANT]
>Denne siden beskriver koden bak flere av tallene brukt i analysen. For å se analyse av dataene, se [Dataanalyse](Dataanalyse). For å se matematikken bak, se [Matematikken](Matematikk)

>[!NOTE]
>All kode er skrevet på engelsk
# Informasjon
Denne siden handler om koden som brukes til å bearbeide datasettet og gjøre det leselig og forståelig. Dette er en viktig del av å hente ut data fra prosjektet siden det du sitter igjen med etter å måle noe kan være flere tusen tall.

>Du kan finne python programmet <a href="numberanalyser.py" download>her</a>
# Gjennomgang
Programmet trenger flere python moduler, om det mangler noen kan de installeres med
`pip install (modul)`

```
import pandas as pd
from math import floor
from termcolor import cprint
from numpy import median
from statistics import mode
```

Disse variablene må oppdateres etter hvilke innstillinger som er brukt og hvordan lysforholdene er.

| frequency | hvor mange målinger hvert minutt                                   |
| --------- | ------------------------------------------------------------------ |
| threshold | hvor forskjellen i lysnivå er mellom standard og når noen passerer |
| laser     | csv filen programmet skal lese fra                                 |
| time      | hvilken kolonne som inneholder tidene                              |
| level     | hvilken kolonne som inneholder lysnivået                           |

```
frequency = 180 #how many times measured per minute
threshold = 38 #light level separating normal and passing through
laser = pd.read_csv("Gjennomgangsbygget.csv") #csv file to read from
time = laser.loc[:, "Run 2:Tid(s)"]
level = laser.loc[:, "Run 2:Illumination(lux)"]
```



Denne delen er den viktigste. Den deler opp dataene i minutter og deretter finner den ut når lysnivået er under det som ble satt tidligere. Når lysnivået blir lavt nok skriver den ned tiden i et array av det nåværende minuttet. Så venter den til lysnivået har steget igjen før den igjen ser etter lave lysnivåer.

```
for min in range(floor(totalminutes)):
    amount.append([])

    print("\n")
    cprint("Minute "+str(min), attrs=["bold"])
    print(min*frequency, "-", min*frequency+frequency)


    for i in range(min*frequency,min*frequency+frequency):  
        if currentwalk == False:            
            if round(level[i]) < threshold:    
                currentwalk = True              
                amount[min].append(time[i])     
                print("adding pass at", i, "after", time[i], "seconds") 
        else:       
            since +=1   
            if round(level[i]) >= threshold:   
	            currentwalk = False
                #print("walkdone after", since, "times")
                since = 0       #reset since (debug)
    print("\nMinute complete")
    print("Passes this minute: "+str(len(amount[min])))

```
Etter at denne delen er ferdig sitter vi igjen med et array av minutter som inneholder flerre array med tidene når noen passerte.



Deretter kan man finne den totale mengden med passeringer med å legge sammen hvor mange passeringer det var hvert minutt.

```
for i in range(len(amount)):
	passes += len(amount[i])
```


For å finne ut mer informasjon senere lager programmet et array med mengden passeringer for hvert minutt.
```
medarr = []
for i in range (len(amount)):
    medarr.append(len(amount[i]))
```



Til slutt skriver programmet ut totale, gjennomsnittlige, median, typetallet og variasjonsbredden av hvor mange passeringer det var hvert minutt. For mer informasjon, se [Matematikkdelen](Matematikk).
```
print("Total passthroughs:", passes)
print("Mean passthroughs per minute:", passes/(totalminutes))
print("Median passthroughs per minute:", median(medarr))
print("Mode passthroughs:", mode(medarr))
print("Range of passthroughs per minute:", str((max(medarr)-min(medarr))))
```

For <a href="testdata.csv" download>dette datasettet</a> er resultatet:
```
Total passthroughs: 108
Mean passthroughs per minute: 1.8305084745762712
Median passthroughs per minute: 1.0
Mode passthroughs: 3
Range of passthroughs per minute: 7
```