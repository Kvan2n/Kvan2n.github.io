
><a href="markdown.zip" download>Last ned markdown filene</a>

# Markdown
Denne nettsiden er laget med markdown-språket og eksportert til HTML. Jeg har laget siden i et program for markdown som heter Obsidian. Markdown er et språk som kan skrives i vanlig tekst og formateres. Det er også mulig å skrive html rett i et markdown dokument. Markdown gjør det enkelt å strukturere og holde oversikt over notater og prosjekter med enkel navigering mellom headings.
For eksempel har jeg brukt markdown sine lenker for å kunne navigere mellom sider. Disse kan lages slik. `[Klikk her](https://youtube.com)`
Men jeg har også brukt HTML for å kunne laste ned filer på samme måte som en gjør det i HTML. `<a href="numberanalyser.py" download>her</a>`
For mer informasjon om markdown er det mye nyttig på [markdown guide.](https://www.markdownguide.org/getting-started/)
# Bakgrunn
Jeg begynte for noen år siden å skrive notater i .txt filer i stedet for i word. Dette ble raskt rotete og uoversiktlig. Etter å ha søkt på internettet etter alternativer fant jeg markdown. Det er allerede mulig å både skrive og vise markdown i Visual Studio Code. (Prøv å åpne en av markdown filene over i VSCode og trykk Ctrl+Shift+V) Markdown gjorde det enkelt å holde oversikt over notater og etter kort tid fant jeg ut at det er mulig å skrive HTML rett inn i markdown.
Jeg har valgt å bruke markdown for dette prosjektet fordi jeg har lyst til å lære mer om markdown og fordi det er generelt veldig enkelt å holde oversikt over alt.